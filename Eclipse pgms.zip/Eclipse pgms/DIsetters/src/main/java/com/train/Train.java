package com.train;

public class Train {

	private int trainno;
	private int ticketprice;
	private String source;
	private String destination;
	
	public int gettrainno() {
		return trainno;
	}
	public void settrainno(int trainno) {
		this.trainno=trainno;
	}
	
	public int getticketprice() {
		return ticketprice;
	}
	public void setticketprice(int ticketprice) {
		this.ticketprice=ticketprice;
	}
	
	public String getsource() {
		return source;
	}
	public void setsourcename(String source) {
		this.source=source;
	}
	public String getdestination() {
		return destination;
	}
	public void setdestination(String destination) {
		this.destination=destination;

	}
	void display() {
		System.out.println("Train number: "+trainno);
		System.out.println("Ticket Price: "+ticketprice);
		System.out.println("Source name : "+source);
		System.out.println("Destination name: "+destination);
		
		
	}
}
