package test.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Testing1 {
	
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\user67\\Documents\\lib\\chromedriver_win32\\chromedriver.exe");
		WebDriver test = new ChromeDriver();
		test.get("https://www.facebook.com/");
		test.findElement(By.xpath("//input[@id='email']")).sendKeys("kiru@gmail.com");
		test.findElement(By.xpath("//input[@id='pass']")).sendKeys("12345");
		test.findElement(By.xpath("//button[@name='login']")).click();
		
	}

}