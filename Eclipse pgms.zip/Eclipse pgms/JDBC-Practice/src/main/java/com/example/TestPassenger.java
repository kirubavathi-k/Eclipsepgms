package com.example;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
public class TestPassenger {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext cx=new ClassPathXmlApplicationContext("applicationContext.xml");
		PassengerDAO dao=(PassengerDAO ) cx.getBean("userDAO");
		
		int result=dao.saveUser(new Passenger("john",23,"male"));
		System.out.println(result);
		int result1=dao.updateUser(new Passenger("johny",22,"male"));
		System.out.println(result1);
		//int result2=dao.deleteUser(new Passenger("john",23,"male"));
		//System.out.println(result2);
		
	}

}
