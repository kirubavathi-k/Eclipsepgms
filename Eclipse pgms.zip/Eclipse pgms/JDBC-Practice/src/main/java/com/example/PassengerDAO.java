package com.example;
import org.springframework.jdbc.core.JdbcTemplate;
public class PassengerDAO {

	
		private JdbcTemplate jdbcTemplate;
		 
		  public JdbcTemplate getJdbcTemplate() {
			return jdbcTemplate;
		}
		public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
			this.jdbcTemplate = jdbcTemplate;
		}
		
		public int saveUser(Passenger pass) {
			 String query="insert into passenger values('"+pass.getName()+"','"+pass.getAge()+"','"+pass.getGender()+"')";
			 return jdbcTemplate.update(query);
		 }
		public int updateUser(Passenger pass) {
			 String query="update passenger set age ='"+ pass.getAge()+"',gender='"+pass.getGender()+"'where name ='"+pass.getName()+"'";
			 return jdbcTemplate.update(query);
		 }
		
		 public int deleteUser(Passenger pass) {
			 
			 String query="delete from passenger where name= '" +pass.getName() +"' ";
			 return jdbcTemplate.update(query);
			 
	}

}


	
