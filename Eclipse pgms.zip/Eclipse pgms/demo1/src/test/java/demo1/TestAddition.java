package demo1;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
import calculation.Calculation;
public class TestAddition {

@Test
public void testAddition(){
	assertEquals(40, Calculation.addition(20,20));
	

	}

}
