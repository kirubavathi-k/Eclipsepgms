package calculation;



public class Calculation {

	public static Object addition(int i, int j) {
		Calculation obj=new Calculation();
		System.out.println("sum of two numbers are : "+obj.addition(20,20));
		return null;
	}

}
