package jdbc;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Scanner;

public class Traincase {

	private static String[] destinations;
	private static String destinations2;

	public static void main(String[] args) {
		int fee=0;
		int s=0;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sampleDB","root","Kiru@123");
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select * from Trains");
			System.out.println("Today's Trains");
			while(rs.next()) {
				System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getInt(5) );
			}
		}
		catch(ClassNotFoundException e) {
			e.printStackTrace();
			}catch (SQLException e) {
				e.printStackTrace();
		}
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter passenger name");
		String name=sc.next();
		System.out.println("Enter date");
		int date=sc.nextInt();
		System.out.println("Enter month");
		int month=sc.nextInt();
		System.out.println("Enter year");
		int year=sc.nextInt();
		System.out.println("Enter age");
		int age=sc.nextInt();
		System.out.println("Enter gender");
		String gender=sc.next();
		System.out.println("Enter train id");
		int train_id=sc.nextInt();
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sampleDB","root","Kiru@123");
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery("select * from Trains");
		System.out.println("Today's Trains");
		while(rs.next()) {
			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getInt(5) );
		    int p=rs.getInt(1);
		    if(p==train_id) {
		    	fee=rs.getInt(5);
		    }
		    if(age<=12) {
		    	s=fee/2;}else {
		    		s=fee;
		    	}
		}
		}
		catch(ClassNotFoundException e) {
			e.printStackTrace();
			}catch (SQLException e) {
				e.printStackTrace();
		}
		System.out.println("Enter Source");
		String source=sc.next();
		System.out.println("Enter destination");
		destinations2 = sc.next();
		System.out.println("ticket is generated in next file kindly print it...");
		String msg="name : "+name+"\r\n";
		//destinations2 = null;
		String msg1="PNR : "+source.charAt(0)+destinations2.charAt(0)+"_"+year+month+date+"_"+101+"\r\n";
		String msg2="From : "+source+"\r\n";
		String msg3="destination : "+destinations2+"\r\n";
		String msg4="Travel date : "+date+"/"+month+"/"+year+"\r\n";
		String msg5="passenger_name  age  gender  fare \r\n";
		String msg6="    "+ name +"       "+ age +"    "+ gender +"    "+ s +"\r\n";
		String msg7="Total Price:"+s+"\r\n";
		try {
			FileWriter fw=new FileWriter("C:\\Users\\user67\\eclipse-workspace\\DBconnect\\train.txt");
			fw.write(msg);
			fw.write(msg1);
			fw.write(msg2);
			fw.write(msg3);
			fw.write(msg4);
			fw.write(msg5);
			fw.write(msg6);
			fw.write(msg7);
			fw.close();
		}
		catch(IOException e) {
			e.printStackTrace();
			
		}
	}
		
		
}
