package com.example;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;


public class TestUser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	/*	Resource rs=new ClassPathResource("applicationContext.xml");
		BeanFactory factory=new XmlBeanFactory(rs);*/
		
		//UserDAO dao=(UserDAO) factory.getBean("userDAO");
		ApplicationContext cx=new ClassPathXmlApplicationContext("applicationContext.xml");
		UserDAO dao=(UserDAO) cx.getBean("userDAO");
		int result=dao.saveUser(new User(101,"john@gmail.com","123456"));
		System.out.println(result);
		/*int result1=dao.deleteUser(new User(101,"john@gmail.com","123456"));
		System.out.println(result1);
		int result2=dao.deleteUser(new User(102,"jimmy@gmail.com","456789"));
		System.out.println(result2);*/
		//int result=dao.updateUser(new User(101,"johny@gmail.com","42424242"));
		//System.out.println(result);
		
		
		
		

	}

}
