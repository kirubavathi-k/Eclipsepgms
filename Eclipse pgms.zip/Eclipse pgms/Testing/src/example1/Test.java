package example1;

class Calculation1{
	public static int subtraction(int x,int y) {
		return x-y;
	}
}
public class Test extends Calculation1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculation1 obj=new Calculation1();
		System.out.println("sub of two numbers are : "+ obj.subtraction(20,20));

	}

}
