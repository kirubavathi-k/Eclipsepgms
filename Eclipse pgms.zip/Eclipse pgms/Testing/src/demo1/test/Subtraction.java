package demo1.test;
import static org.junit.Assert.assertEquals;
import example1.*;
import org.junit.Test;

public class Subtraction {


	    @Test
		public void testSub(){
		//assertEquals(0,Test.subtraction(20,20));
		
		
		

	}

}
