package demo.test;
import static org.junit.Assert.assertEquals;
import example.*;
import org.junit.Test;
public class Addition {


	  @Test
		public void testAdd(){
		assertEquals(60,Test1.addition(30,30));
		assertEquals(50,Test1.addition(30,20));
		assertEquals(40,Test1.addition(20,20));
		
		

	}

}
