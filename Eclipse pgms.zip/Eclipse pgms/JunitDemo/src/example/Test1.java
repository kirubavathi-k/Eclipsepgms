package example;
class Calculation{
	public static int addition(int x,int y) {
		return x+y;
	}
}
public class Test1 extends Calculation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculation obj=new Calculation();
		System.out.println("sum of two numbers are : "+obj.addition(20,20));

	}

}
