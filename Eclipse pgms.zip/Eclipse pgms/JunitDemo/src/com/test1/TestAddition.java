package com.test1;
import static org.junit.Assert.assertEquals;
import org.junit.After;
import org.junit.Before;

import com.example.*;
import org.junit.Test;

public class TestAddition {

	@Before
	public void beforeTest() {
		System.out.println("Executed Before Test");
	}
	@Test
	public void testAdd() {
		System.out.println("Actual Tests");
		//assertEquals(60,TestDemo1.addition(30,30));
	}
	@After
	public void afterTest() {
		System.out.println("Executed After Test");
		
	}

}
