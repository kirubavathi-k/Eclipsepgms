package com.test.ValidateUser;

import static org.junit.Assert.assertEquals;

import com.example.User.Test2;
//import com.test.ValidateUser.*;

import org.junit.Test;
public class Check {
      @Test
	public void validateuser() {
		assertEquals("User is valid" ,Test2.validateuser("admin", "admin123"));
	}
}
	



