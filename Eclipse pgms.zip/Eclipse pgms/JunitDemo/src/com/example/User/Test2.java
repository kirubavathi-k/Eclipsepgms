package com.example.User;
import java.util.*;
public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String uname="admin";
		String pass="admin123";
		String username=sc.next();
		String password=sc.next();
		if(username.equals(uname) && password.equals(pass)) {
			System.out.println("true");
		}else {
			System.out.println("false");
		}
	}

	public static Object validateuser(String uname, String pass) {
		return "User is valid";
	
	
		
	}

}
