package javaio;

import java.io.FileWriter;
import java.io.IOException;

public class Test4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String msg="welcome to my application";
		try {
			FileWriter fw= new FileWriter("C:\\\\Users\\\\user67\\\\eclipse-workspace\\\\Project1\\\\hello.txt");
			fw.write(msg);
			fw.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
		System.out.println("Done....");

	}

}
