package javaio;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.File;

public class Test3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File f=new File("C:\\Users\\user67\\eclipse-workspace\\Project1\\hello.txt");
		try {
			FileReader r=new FileReader(f);
			int i;
		    while((i=r.read())!=-1) {
		    	System.out.print((char)i);
		    }
		}catch(FileNotFoundException e) {
		    	e.printStackTrace();
		    }catch(IOException e) {
		    	e.printStackTrace();
		    }
		}

	

			
		

	}


