package javaio;
import java.io.FileWriter;
import java.io.IOException;
import org.json.simple.JSONObject;
public class JsonTest5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String msg="welcome to my application";
		try {
			
		FileWriter fw= new FileWriter("C:\\Users\\user67\\eclipse-workspace\\Project1\\src\\javaio\\json.txt");
		JSONObject obj=new JSONObject();
		obj.put("id", 1);
		obj.put("name", "John");
		obj.put("age", "25");
		
		
		fw.write(obj.toJSONString());
			fw.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
		System.out.println("Done....");

	}

	}


