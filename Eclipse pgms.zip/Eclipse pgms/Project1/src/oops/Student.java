package oops;
class Stu{
	String name="john";
	String degree="BE";
	String dept="ECE";
	String id="17EC674";
}
public class Student {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stu obj=new Stu();
		System.out.println(obj.name);
		System.out.println(obj.degree);
		System.out.println(obj.dept);
		System.out.println(obj.id);

	}

}
