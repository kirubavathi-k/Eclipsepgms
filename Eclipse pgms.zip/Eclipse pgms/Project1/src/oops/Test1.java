package oops;

class car{
	String brand="SUV";
	String model="range rover";
	String color="black";
	double price=6300000.90;
}
public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		car obj=new car();
		System.out.println(obj.brand);
		System.out.println(obj.model);
		System.out.println(obj.color);
		System.out.println(obj.price);

	}

}
