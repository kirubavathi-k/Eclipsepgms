package oops;
import accessspecifiers.*;
public class Test8 {

	int number=30;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test8 obj=new Test8();
		System.out.println("number is : "+obj.number);
		
		TestSpecifier1 obj1=new TestSpecifier1();
	//	System.out.println(obj1.value);  //cant access outside the package
    //    System.out.println(obj1.city);
	}

}
