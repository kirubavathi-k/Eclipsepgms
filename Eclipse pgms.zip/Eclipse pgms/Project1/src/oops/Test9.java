package oops;
import accessspecifiers.*;
public class Test9 extends TestSpecifier1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test9 obj=new Test9();
		System.out.println(obj.city);    //able to access protected by calling package accessspecifiers
		                                 //it must inherited

	}

}
