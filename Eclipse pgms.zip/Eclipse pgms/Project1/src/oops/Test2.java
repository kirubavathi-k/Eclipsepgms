package oops;
class Person{
	int id;
	String name;
	//constructor
	Person()
	{
		id=101;
		name="john";
		}
	void display()
	{
		System.out.println(id+" "+name);
	}
}
public class Test2 {

	public static void main(String[] args) {
		Person obj=new Person();
		obj.display();

	}

}
