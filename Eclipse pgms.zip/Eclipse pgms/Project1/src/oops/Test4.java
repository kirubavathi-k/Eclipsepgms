package oops;
class Book1{
	
	Book1(){
		System.out.println("Default constructor gets executed");
	}
}
public class Test4 {
	public static void main(String args[])
	{
	Book1 b1=new Book1();
	Book1 b2=new Book1();
	
	}

}
