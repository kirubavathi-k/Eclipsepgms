package oops;
class Book{
	int bookid = 101;
	String bookname="java";

void display() {
	System.out.println(bookid+" "+bookname);
}}
public class Test3 {

	public static void main(String[] args) {
		Book b1=new Book();
	    b1.display();

	}

}
