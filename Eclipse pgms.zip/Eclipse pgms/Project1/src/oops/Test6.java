package oops;
class Library{
	int bookid;
	String bookname;
	String authorname;

Library(){
	System.out.println("Default constructor");
}
Library(int bookid,String bookname,String authorname){
	this.bookid=bookid;
	this.bookname=bookname;
	this.authorname=authorname;
}
void display() {
	System.out.println(bookid+" "+bookname+" "+authorname);
}
}
public class Test6 {

	public static void main(String[] args) {
		Library L1=new Library(101, "c++", "Bjarne");
		L1.display();
		Library L2=new Library(110, "java", "James");
		L2.display();

	}

}

