package oops;
class Bike{
	int speed;
	String name;
	String color;

Bike(){
	System.out.println("Default constructor");
}
Bike(int speed,String name,String color){
	this.speed=speed;
	this.name=name;
	this.color=color;
}
void display() {
	System.out.println(speed+" "+name+" "+color);
}
}
public class Test5 {

	public static void main(String[] args) {
		Bike b1=new Bike(120, "Yamaha", "black");
		b1.display();
		Bike b2=new Bike(110, "Honda", "blue");
		b2.display();

	}

}
