package javainterface;
interface I2{
	void show();
}
interface I3{
	void display();
}

public class Testinterface2 implements I2,I3 {


	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("msg from display");
		
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("msg from show");
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Testinterface2 obj=new Testinterface2();
		obj.display();
		obj.show();
		

}}
