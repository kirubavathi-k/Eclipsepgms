package javainterface;
//sum of two numbers using interface
interface Add{
	void addition(int x,int y);
}
public class Testinterface4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//AIC:Anonymous inner class
		Add obj=new Add() {
			public void addition(int x,int y) {
				int res;
				res=x+y;
				System.out.println("sum of two numbers are: "+res);
			}
		};
		obj.addition(40,40);
		

	}

}
