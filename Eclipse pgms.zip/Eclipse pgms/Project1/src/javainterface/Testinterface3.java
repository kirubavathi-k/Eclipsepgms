package javainterface;
interface I4{
	void add();
	
}
interface I5 extends I4{
	void mul();
}
public class Testinterface3 implements I5 {

	
	@Override
	public void add() {
		// TODO Auto-generated method stub
		System.out.println("Addition");
	}

	@Override
	public void mul() {
		// TODO Auto-generated method stub
		System.out.println("Multiplication");
	}

public static void main(String[] args) {
	// TODO Auto-generated method stub
 Testinterface3 obj=new Testinterface3();
 obj.add();
 obj.mul();
}}
