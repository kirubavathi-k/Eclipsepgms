package javainterface;
interface I1{
	void display();
	void calculate();
}
public class Testinterface1 implements I1 {
	
//method should be public
	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("Message from display");
	}

	@Override
	public void calculate() {
		// TODO Auto-generated method stub
		System.out.println("Message from calculate");
		
	}


public static void main(String[] args) {
	// TODO Auto-generated method stub
	Testinterface1 obj=new Testinterface1();
	obj.calculate();
	obj.display();

}}
