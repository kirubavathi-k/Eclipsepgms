package javapractice_pgms;



class Doctor{
	String designation = "Doctor";
	String hos_name="ABC";
}
class ChildSpecialist extends Doctor{
	String experience="twenty";

public static void main(String[] args) {
		ChildSpecialist obj=new ChildSpecialist();
		System.out.println(obj.hos_name);
		System.out.println(obj.designation);
		System.out.println(obj.experience);
         
 
	}

}
