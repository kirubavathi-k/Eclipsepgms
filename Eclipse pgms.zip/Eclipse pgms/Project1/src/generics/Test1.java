package generics;
class A<T>{
	T i;
	A(T val){
		this.i=val;
	}
	T getObject() {
		return this.i;
	}
}
public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A<Integer> obj=new A<Integer>(20);
		System.out.println(obj.getObject());
		A<String> obj1=new A<String>("John");
		System.out.println(obj1.getObject());

	}

}
