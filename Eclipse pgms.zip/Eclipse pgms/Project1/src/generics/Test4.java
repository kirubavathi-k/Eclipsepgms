package generics;

import java.util.ArrayList;

public class Test4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> al=new ArrayList<String>();
		al.add("john");
		al.add("jimmy");
		al.add("jack");
		//al.add(10);
		System.out.println(al.get(2));
		

	}

}
