package generics;
class B<T,U>{
	T p1;
	U p2;
	B(T p1,U p2){
		this.p1=p1;
		this.p2=p2;
	}
	void display() {
		System.out.println(p1+" "+p2);
	}
}

public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B<String,Integer> obj1=new B<String,Integer>("xyz",30);
		obj1.display();
	
	}

}
