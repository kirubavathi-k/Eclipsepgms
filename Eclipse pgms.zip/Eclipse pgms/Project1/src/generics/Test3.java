package generics;

public class Test3 {
	static <T> void display(T item) {
		System.out.println(item.getClass().getName()+" "+item);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		display(200);
		display("john");

	}

}
