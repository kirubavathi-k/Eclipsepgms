package basic_pgms;

//import java.util.Scanner;

public class Rev {

	public static void main(String[] args) {
		/*Scanner sc=new Scanner(System.in);
	    String str, org, rev; 
		str=sc.next();
	    org=str;
	     rev="";
	     int len=str.length();
	     for(int i=len-1;i>=0;i--)
	     {
	    	 rev=rev+str.charAt(i);
	     }
     System.out.println(rev);
	}
}*/
		int num=123456789;
		int rev=0;
		while(num!=0)
		{
			rev=rev*10 + num%10;
			num=num/10;
		}
		System.out.println(rev);

	}
}


