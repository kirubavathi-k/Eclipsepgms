package basic_pgms;

public class Swap {

	public static void main(String[] args) {
		int a=10,b=20;
		System.out.println("Before swapping values are "+a+" "+b);
		//logic 1                    
		int t=a;              
		  a=b;
		  b=t;
		System.out.println("After swapping "+a+" "+b);
		
		a=a*b;
		b=a/b;
		a=a/b;
		System.out.println("After swapping "+a+" "+b);
		
		

	}

}
