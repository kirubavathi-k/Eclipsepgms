package basic_pgms;

//5!=1*2*3*4*5=120
public class Fact {

	public static void main(String[] args) {
		int num=5;
		long factorial=1;
		for(int i=1;i<=num;i++)
		{
		 factorial=factorial*i;
		}
System.out.println(factorial);
	}

}
