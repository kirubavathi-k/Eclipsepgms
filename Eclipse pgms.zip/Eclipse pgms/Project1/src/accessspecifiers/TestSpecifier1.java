package accessspecifiers;

public class TestSpecifier1 {
	private static int number=300;
static int value=300;
protected String city="chennai";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(number);
		System.out.println(value);

	}

}
