package accessspecifiers;

public class TestSpecifier2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println(TestSpecifier1.number); //private member of another class is not visible
//if we remove private in TestSpecifier1 error disappeared automatically
		System.out.println(TestSpecifier1.value);
        TestSpecifier1 obj=new  TestSpecifier1();
        System.out.println(obj.city);
	
	}

}
