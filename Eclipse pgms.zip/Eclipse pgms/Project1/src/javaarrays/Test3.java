package javaarrays;

public class Test3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int arr[]= {20,40,60,80,100};
for(int i:arr) {
	System.out.println(i);
	}

}
}