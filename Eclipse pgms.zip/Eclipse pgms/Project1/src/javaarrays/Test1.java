package javaarrays;

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr[]=new int[5];
		arr[0]=10;
		arr[1]=11;
		arr[2]=12;
		arr[3]=13;
		arr[4]=14;
		
		for(int i=0;i<arr.length;i++) {
		System.out.println(arr[i]);
	}

}}
