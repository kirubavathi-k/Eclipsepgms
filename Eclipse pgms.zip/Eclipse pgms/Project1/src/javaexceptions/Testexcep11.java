package javaexceptions;

public class Testexcep11 {

	static boolean checknumber(int n) {
		if(n==0) {
			throw new ArithmeticException("Divide by zero error");
		}else {
			return true;
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=200;
		int num2=0;
		int result;
		System.out.println(1);
		try {
			if(checknumber(num2)) {
				result=num1/num2;
				System.out.println("Division result of two numbers is : " + result);
				
			}
		}catch(Exception e) {
			System.out.println("from catch inside main : " + e.getMessage());
		}
		System.out.println(2);

	}

}
