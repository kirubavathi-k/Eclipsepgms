package javaexceptions;

public class TestExcep5 {
     int num=50;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
 try {
	 System.out.println(5/0);
 }catch(NullPointerException e) {
	 System.out.println("I am Null");
	 System.out.println(e);
	 
 }
	}

}
