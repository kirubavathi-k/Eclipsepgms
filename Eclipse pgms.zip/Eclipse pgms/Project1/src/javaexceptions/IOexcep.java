package javaexceptions;
import java.io.IOException;


class Abc{
	void display() throws IOException{
		System.out.println("Message from display");
		throw new IOException("Input output error");
	}
}

public class IOexcep {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
Abc obj=new Abc();
obj.display();
	}

}
