package javaexceptions;

public class Nullpointer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name=null;
		//System.out.println(name.length());
		try {
			System.out.println(name.length());
			
		}catch(NullPointerException e) {
			e.printStackTrace();  //instead of syso it shows the error
			//System.out.println(e.getMessage());
			//System.out.println(e.toString());
		}

	}

}
