package javaexceptions;

class InvalidUserException extends Exception{
	public InvalidUserException(String msg) {
		super(msg);
	}
}
public class CustomException {

	static void validateUser(String Username,String password) throws InvalidUserException{
		if(Username.equals("admin")&&password.equals("admin123"))
		{
			System.out.println("User is valid");
		}else {
			throw new InvalidUserException("Invalid user");
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
  try {
	 // validateUser("admin","admin123");   //shows user is valid
	  validateUser("admin","admin1234");    //shows exception
  }catch(InvalidUserException e) {
	  e.printStackTrace();
  }
	}

}
