package javaexceptions;

public class Arithmeticexcep {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  int num=40;
  try {
	  System.out.println(40/0);
  }catch(ArithmeticException e)
  {
	  System.out.println(e);
  }
	}

}
