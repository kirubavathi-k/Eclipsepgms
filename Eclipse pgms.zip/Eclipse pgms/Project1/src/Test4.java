
public class Test4 {

	public static void main(String[] args) {
		String name="John";
		System.out.println("Name is:"+name);
		

	}

}
