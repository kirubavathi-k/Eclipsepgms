package javaoperators;

public class Relational {

	public static void main(String[] args) {
		int num1=30;
		int num2=50;
		System.out.println(num1 < num2);
		System.out.println(num1 > num2);

	}

}
