package javaoperators;

public class Arithmetic {

	public static void main(String[] args) {
		int num1=20;
		int num2=5;
		System.out.println(num1 +num2);
		System.out.println(num1 - num2);	
		System.out.println(num1 * num2);
		System.out.println(num1 / num2);
		
	}

}
