package javaoperators;

public class Ternary {

	public static void main(String[] args) {
	   int num1=30;
	   int num2=20;
	   int res=(num1<num2)?num1:num2;
	   System.out.println(res);

	}

}
