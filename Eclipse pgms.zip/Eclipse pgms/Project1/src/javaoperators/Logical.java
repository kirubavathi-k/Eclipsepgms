package javaoperators;

public class Logical {

	public static void main(String[] args) {
		boolean flag1=true;
		boolean flag2=false;
		System.out.println(flag1 && flag2);
		System.out.println(flag1 || flag2);

	}

}
