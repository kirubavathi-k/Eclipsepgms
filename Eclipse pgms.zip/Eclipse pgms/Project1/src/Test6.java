
public class Test6 {

	final static int number=200;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//number=500;                 //cant change final variable
		System.out.println(number);

	}

}
