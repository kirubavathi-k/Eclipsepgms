package javainheritance;

class Parent{
	public void property() {
		System.out.println("property");
	}
}
class Child extends Parent{
	public void job() {
		System.out.println("job");
	}
}
public class Is_a_relationship {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Child c=new Child();
		c.property();
		c.job();
		
		

	}

}
