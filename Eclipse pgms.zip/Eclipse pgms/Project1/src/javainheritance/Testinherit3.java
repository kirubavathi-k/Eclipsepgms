package javainheritance;
//multi level inheritance
class A11{
	int num1=100;
}
class B11 extends A11{
	int num2=200;
}
class C11 extends B11{
	int num3=300;
	int result;

void addition()
{
	result=num1+num2+num3;
	System.out.println("sum of three numbers are:"+result);
}}
public class Testinherit3 {
public static void main(String[] args) {
	C11 obj=new C11();
	obj.addition();

	}
}

