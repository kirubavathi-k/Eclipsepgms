package javainheritance;
class A1{
	int num1=20;
}
class A2 extends A1{
	int num2=30;
	int result;
	void addition() {
		result=num1+num2;
		System.out.println("sum of two numbers are : "+result);
	}
}

public class Testinherit2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A2 obj=new A2();
		obj.addition();

	}

}
