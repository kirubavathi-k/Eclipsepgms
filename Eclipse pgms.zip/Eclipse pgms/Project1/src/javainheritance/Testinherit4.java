package javainheritance;
//diamond shaped inheritance R12 and S12 inherits Q12
class A12{
	
	int num1=90;
}
class B12 extends A12{
	int num2=30;
	int res;
	
	void cal() {
		res=num1*num2;
		System.out.println(res);
	}
}
class C12 extends A12{
	int num2=40;
	int res;
	
	void cal() {
		res=num1/num2;
		System.out.println(res);
}
}
class D12 extends C12{
	void display()
	{
		System.out.println("message from class D12");
		cal();
	}
}
public class Testinherit4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   D12 obj=new D12();
   obj.display();
	}

}
