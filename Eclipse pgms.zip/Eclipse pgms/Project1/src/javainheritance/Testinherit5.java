package javainheritance;

class Bike{
	int speed=100;
	Bike(){
		System.out.println("Bike is running at speed"+speed+"km/hr");
	}
  void display() {
	  System.out.println("message from display");
  }
}
class Honda extends Bike{
	int speed=200;
	Honda(){
		super(); //invokes parent class constructor
		System.out.println("Bike Honda is good");
	}
void show() {
	System.out.println(super.speed);
	System.out.println(this.speed);
    super.display();
}}
public class Testinherit5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Honda obj=new Honda();
		obj.show();

	}

}
