
public class Test3 {

	public static void main(String[] args) {
		int marks[]= {65,36,27,48,39,32};
                   // 0  1  2  3  4  5
		System.out.println(marks[4]);
	}

}
