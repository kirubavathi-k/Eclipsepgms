package javacollections;

import java.util.Arrays;
import java.util.Set;
import java.util.HashSet;

public class TestSet3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Integer> s1=new HashSet<Integer>();
		s1.addAll(Arrays.asList(new Integer[] {1,3,5,7,9}));
		
		Set<Integer> s2=new HashSet<Integer>();
		s2.addAll(Arrays.asList(new Integer[] {2,3,4,5}));
		
		Set<Integer> union=new HashSet<Integer>(s1);
		union.addAll(s2);
		System.out.println(union);
		
		Set<Integer> intersection=new HashSet<Integer>(s1);
		intersection.retainAll(s2);
		System.out.println(intersection);
		
		
		Set<Integer> difference=new HashSet<Integer>(s1);
		difference.removeAll(s2);
		System.out.println(difference);
		
		
		
		
	

	}

}
