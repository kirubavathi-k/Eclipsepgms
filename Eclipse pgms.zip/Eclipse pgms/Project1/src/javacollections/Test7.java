package javacollections;
import java.util.Iterator;
import java.util.Stack;
public class Test7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  Stack<String> obj=new Stack<String>();
  obj.push("abi");
  obj.push("anu");
  obj.push("arthi");
  obj.push("akshaya");
  Iterator it=obj.iterator();
  while(it.hasNext()) {
	  System.out.println(it.next());
	  
  }
  System.out.println("--------------------------------");
  obj.pop();
  Iterator it1= obj.iterator();
  while(it1.hasNext()) {
	  System.out.println(it1.next());
  }
  }
  
	}


