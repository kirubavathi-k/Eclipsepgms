package javacollections;
import java.util.HashSet;
import java.util.Set;
public class TestSet {

	//set-unordered set of elements(doesn't allow duplicate value)
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<String> s=new HashSet<String>();
		s.add("mango");
		s.add("apple");
		s.add("papaya");
		s.add("banana");
		s.add("mango");
		System.out.println(s);

	}

}
