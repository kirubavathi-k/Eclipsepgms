package javacollections;
import java.util.Set;
import java.util.HashSet;
import java.util.Iterator;
public class TestSet2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Integer> s=new HashSet<Integer>();
		s.add(10);
		s.add(20);
		s.add(30);
		s.add(40);
		s.add(50);
		//System.out.println(s);
		Iterator it=s.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		

	}

}
