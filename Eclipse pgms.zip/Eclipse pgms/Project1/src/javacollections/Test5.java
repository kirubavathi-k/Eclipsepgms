package javacollections;

import java.util.Iterator;
import java.util.LinkedList;

public class Test5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 LinkedList<String> obj=new LinkedList<String>();
	     obj.add("john");
	     obj.add("jimmy");
	     obj.add("abi");
	     obj.add("anu");
	     obj.add("priya");
	     Iterator it=obj.iterator();
	     while(it.hasNext()) {
	    	 System.out.println(it.next());

	}

}
}
