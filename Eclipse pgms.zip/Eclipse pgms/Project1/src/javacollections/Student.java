package javacollections;

import java.util.LinkedList;
import java.util.Scanner;
public class Student {

	private String name;
	private String address;
	private double GPA;
	
	static LinkedList<Student> al=new LinkedList<Student>();
	static Scanner sc=new Scanner(System.in);
	public Student(String name,String address, double gpa) {
		super();
		this.name=name;
		this.address=address;
		GPA=gpa;
	}
	
		public String getName() {
		return this.name;
	}
	public String getAddr() {
		return this.address;
	}
	public double getGPA() {
		return this.GPA;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=0;i<=2;i++)
		{
			System.out.println("Enter Student name: ");
		    String name=sc.next();
		    System.out.println("Enter Student Address: ");
		    String address=sc.next();
		    System.out.println("Enter Student GPA: ");
		    double gpa=sc.nextDouble();
		    al.addLast(new Student(name,address,gpa));
		}
		System.out.println(al);
	}
	
	@Override
	public String toString() {
		return "Student [name=" + name + ", address=" + address + ", GPA=" + GPA + "]";
	}
	

}
