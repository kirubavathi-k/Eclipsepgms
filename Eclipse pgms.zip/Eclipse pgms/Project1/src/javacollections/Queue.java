package javacollections;
import java.util.Iterator;
import java.util.PriorityQueue;

public class Queue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PriorityQueue<String> pq=new PriorityQueue<String>();
		pq.add("Andrew");
		pq.add("Simon");
		pq.add("Alex");
		pq.add("Sandra");
		//pq.add(null);      //queue doesn't accept null
		pq.add("peter");
		
		Iterator it1=pq.iterator();
		while(it1.hasNext()) {
			System.out.println(it1.next());
		}
		System.out.println("---------------------");
		pq.remove();
		//pq.poll(); //poll also used to remove
		Iterator it2=pq.iterator();
		while(it2.hasNext()) {
			System.out.println(it2.next());
		}
		

	}

}
