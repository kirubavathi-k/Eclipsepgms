package javacollections;
import java.util.HashMap;

public class TestHashmap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer,String> map=new HashMap<Integer,String>();
		map.put(1, "john");
		map.put(2, "abhi");
		map.put(3, "tommy");
		map.put(4, "jerry");
		map.put(5, "radha");
		map.put(6, "rohan");
		System.out.println(map.get(4));
		System.out.println(map.get(7));
		

	}

}
