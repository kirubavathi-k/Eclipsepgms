package javacollections;

import java.util.Iterator;
import java.util.LinkedList;

public class Test4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     LinkedList<Integer> obj=new LinkedList<Integer>();
     obj.add(10);
     obj.add(20);
     obj.add(30);
     obj.add(40);
     obj.add(50);
     Iterator it=obj.iterator();
     while(it.hasNext()) {
    	 System.out.println(it.next());
     }
     
	}

}
