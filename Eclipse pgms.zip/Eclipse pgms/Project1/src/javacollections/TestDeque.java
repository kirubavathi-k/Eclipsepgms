package javacollections;
import java.util.LinkedList;
import java.util.Deque;
public class TestDeque {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Deque<String> deque=new LinkedList<String>();
		deque.add("string1");
		deque.add("string2");
		deque.add("string3");
		deque.add("string4");
		deque.add("string5");
		System.out.println(deque);
		
		deque.pop();
		System.out.println("----------------------");
		System.out.println(deque);
		System.out.println("----------------------");
		deque.pollFirst();     //removes first string
		System.out.println(deque);
		System.out.println("----------------------");
		deque.pollLast();     //removes last string
		System.out.println(deque);
		
		

	}

}
