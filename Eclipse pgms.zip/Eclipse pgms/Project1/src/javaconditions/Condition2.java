package javaconditions;

public class Condition2 {

	public static void main(String[] args) {
		int per=75;
		if(per>=85 && per<=100)
		{
			System.out.println("FCD");
		}else if(per>=60 && per<85) {
			System.out.println("First class");
		}else if(per>=35 && per<60) {
			System.out.println("Pass class");
		}else if(per>=0 && per<35) {
			System.out.println("Fail");	
		}else {
			System.out.println("Enter per between 0 and 100");	
		}
}
}