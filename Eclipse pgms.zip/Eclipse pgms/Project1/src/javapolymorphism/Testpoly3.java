package javapolymorphism;

//Method overriding

class A1{
	int value=100;
	void display()
	{
		System.out.println("msg from display A1"+value);
	}
}
class B1 extends A1{
	void display() {
		value=200;
		System.out.println("msg from display B1 "+value);
	}
}
	

public class Testpoly3 {

	public static void main(String[] args) {
		B1 obj=new B1();
		obj.display();

	}

}
