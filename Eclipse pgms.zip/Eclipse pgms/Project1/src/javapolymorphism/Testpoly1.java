package javapolymorphism;
//Method overloading
class Calculation{
	int addition(int x, int y) {
		return x+y;
	}
	int addition(int x, int y, int z) {
		return x+y+z;
	}
	
}
public class Testpoly1 {

	public static void main(String[] args) {
		
int result;

Calculation obj=new Calculation();

result=obj.addition(30, 30,30);
System.out.println(result);

result=obj.addition(40, 40);
System.out.println(result);
	}

}
