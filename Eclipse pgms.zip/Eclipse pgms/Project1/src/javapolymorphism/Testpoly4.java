package javapolymorphism;

class Vehicle{
	void display() {
		System.out.println("vehicle is running");
	}
}
class Bike extends Vehicle{
	void display() {
		System.out.println("Bike is running");
	}
}
public class Testpoly4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bike obj=new Bike();
		obj.display();

	}

}
