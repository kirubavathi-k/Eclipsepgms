package javapolymorphism;

class Calculation1{
	int addition(int x,int y) {
		return x+y;
	}
	
	double addition(double x,double y) {
		return x+y;
	}
}
public class Testpoly2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double res;
		int res1;
		Calculation1 obj=new Calculation1();
		res=obj.addition(20.2, 23.9);
		System.out.println(res);
	
		res1=obj.addition(30,30);
		System.out.println(res1);
		
		

	}

}
