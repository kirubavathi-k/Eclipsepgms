package javaabstraction;

abstract class A{
	int num=20;
	void display() {
		System.out.println(num);
	}
	abstract void calculate();
}

public class TestAbstract1 extends A {
	void calculate() {
		System.out.println("message from calculate");
	}

	public static void main(String[] args) {
		TestAbstract1 obj=new TestAbstract1();
		obj.calculate();
		obj.display();

	}

}
