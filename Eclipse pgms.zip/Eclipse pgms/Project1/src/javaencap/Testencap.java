package javaencap;

public class Testencap {

	public static void main(String[] args) {
		
		User u1=new User();
		u1.setUserName("John");
		u1.setPassword("John123");
		
		User u2=new User();
		u2.setUserName("Jimmy");
		u2.setPassword("Jimmy123");
		
		System.out.println(u1.getUserName()+" "+u1.getPassword());
      System.out.println(u2.getUserName()+" "+u2.getPassword());
		
		Product p1=new Product();
		p1.setProductId(101);
		p1.setProductName("Laptop");
		p1.setProductPrice(70000);
		
		Product p2=new Product();
		p2.setProductId(102);
		p2.setProductName("Desktop");
		p2.setProductPrice(50000);
		
		System.out.println(p1.getProductId()+ " "+p1.getProductName()+ " "+p1.getProductPrice());
		System.out.println(p2.getProductId()+ " "+p2.getProductName()+ " "+p2.getProductPrice());
		
		
		
	}

}
