package com.example1;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class TestPassenger {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
    Resource rs=new ClassPathResource("applicationContext.xml");
				BeanFactory factory=new XmlBeanFactory(rs);
				
				Passenger pass=(Passenger) factory.getBean("passBean");
				pass.display();

				Passenger pass1=(Passenger) factory.getBean("passBean1");
				pass1.display();
				
				
				

			}

		


	}


