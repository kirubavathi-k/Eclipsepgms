package com.example1;

public class Passenger {

		 private String passengername;
		 private int age;
		 private String gender;
		 
	 public Passenger() {
		 System.out.println("Default constructor invoked!!");

		}
	 public Passenger(String passengername,int age,String gender) {
		 this.passengername=passengername;
		 this.age=age;
		 this.gender=gender;
	 }
	 void display() {
		 System.out.println("Passenger Name : "+passengername);
		 System.out.println("Passenger Age  : "+age);
		 System.out.println("Passenger Gender : "+gender+"\n");
	 }
	 

	}


